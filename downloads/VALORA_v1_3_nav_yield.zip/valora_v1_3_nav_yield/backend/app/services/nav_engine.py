from decimal import Decimal
from ..core.decimal_math import D, money

class NavEngine:
    @staticmethod
    def validate_units(units):
        units = D(units)
        if units <= 0:
            raise ValueError("Units must be positive")
        return units

    @classmethod
    def unit_price(cls, nav, units):
        nav = D(nav)
        units = cls.validate_units(units)
        if nav < 0:
            raise ValueError("NAV cannot be negative")
        return money(nav / units)

    @classmethod
    def value(cls, units, unit_price):
        units = D(units)
        unit_price = D(unit_price)
        if units < 0 or unit_price < 0:
            raise ValueError("Units and unit price cannot be negative")
        return money(units * unit_price)

    @classmethod
    def profit(cls, units, current_price, principal):
        current_value = cls.value(units, current_price)
        principal = money(principal)
        return money(current_value - principal)

    @classmethod
    def roi_percent(cls, current_value, principal):
        current_value = money(current_value)
        principal = money(principal)
        if principal <= 0:
            raise ValueError("Principal must be positive")
        return (current_value - principal) / principal * Decimal("100")
