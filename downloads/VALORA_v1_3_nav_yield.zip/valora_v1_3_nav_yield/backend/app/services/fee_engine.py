from decimal import Decimal
from ..core.decimal_math import D, money

class FeeEngine:
    @staticmethod
    def percentage(amount, fee_percent):
        amount = money(amount)
        fee_percent = D(fee_percent)
        if amount < 0 or fee_percent < 0:
            raise ValueError("Amount and fee cannot be negative")
        return money(amount * fee_percent / Decimal("100"))

    @staticmethod
    def net_after_fee(amount, fee_percent):
        return money(money(amount) - FeeEngine.percentage(amount, fee_percent))
