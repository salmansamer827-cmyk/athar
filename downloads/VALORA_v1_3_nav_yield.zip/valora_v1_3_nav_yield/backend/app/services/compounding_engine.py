from decimal import Decimal
from ..core.decimal_math import D, money

class CompoundingEngine:
    @staticmethod
    def apply(value, period_return, fee=Decimal("0")):
        value = money(value)
        period_return = D(period_return)
        fee = money(fee)
        if value < 0 or period_return < 0 or fee < 0:
            raise ValueError("Invalid compounding parameters")

        gross = value * (Decimal("1") + period_return)
        net = gross - fee
        if net < 0:
            raise ValueError("Net value cannot be negative")
        return money(net)
