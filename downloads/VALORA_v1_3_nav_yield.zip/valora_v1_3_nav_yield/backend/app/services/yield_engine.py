from decimal import Decimal
from ..core.decimal_math import D, money

class YieldEngine:
    @staticmethod
    def period_rate_from_apr(apr_percent, periods_per_year=365):
        apr = D(apr_percent)
        n = D(periods_per_year)
        if apr < 0 or n <= 0:
            raise ValueError("Invalid APR or periods")
        return (apr / Decimal("100")) / n

    @staticmethod
    def effective_period_rate_from_apy(apy_percent, periods_per_year=365):
        apy = D(apy_percent)
        n = D(periods_per_year)
        if apy < 0 or n <= 0:
            raise ValueError("Invalid APY or periods")
        return (Decimal("1") + apy / Decimal("100")) ** (Decimal("1") / n) - Decimal("1")

    @classmethod
    def simple_accrual(cls, principal, period_rate):
        principal = money(principal)
        rate = D(period_rate)
        if principal < 0 or rate < 0:
            raise ValueError("Principal/rate cannot be negative")
        return money(principal * rate)

    @classmethod
    def compound(cls, principal, period_rates):
        value = D(principal)
        if value < 0:
            raise ValueError("Principal cannot be negative")
        for rate in period_rates:
            rate = D(rate)
            if rate < 0:
                raise ValueError("Period rate cannot be negative")
            value *= Decimal("1") + rate
        return money(value)
