from fastapi import APIRouter
from ..services.nav_engine import NavEngine
from ..services.yield_engine import YieldEngine

router = APIRouter(prefix="/performance", tags=["performance"])

@router.get("/quote")
def performance_quote(
    principal: str,
    units: str,
    unit_price: str,
):
    value = NavEngine.value(units, unit_price)
    profit = NavEngine.profit(units, unit_price, principal)
    roi = NavEngine.roi_percent(value, principal)

    return {
        "principal": str(principal),
        "units": str(units),
        "unit_price": str(unit_price),
        "nav": str(value),
        "profit": str(profit),
        "roi_percent": str(roi),
    }

@router.get("/daily-rate")
def daily_rate(apr_percent: str):
    rate = YieldEngine.period_rate_from_apr(apr_percent)
    return {
        "apr_percent": apr_percent,
        "periods_per_year": 365,
        "daily_rate": str(rate),
    }
