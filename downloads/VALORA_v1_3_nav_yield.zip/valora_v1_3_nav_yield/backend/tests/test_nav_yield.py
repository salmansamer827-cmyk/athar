from decimal import Decimal
import pytest

from app.services.nav_engine import NavEngine
from app.services.yield_engine import YieldEngine
from app.services.compounding_engine import CompoundingEngine
from app.services.fee_engine import FeeEngine

def test_nav_value():
    assert NavEngine.value("100", "1.035") == Decimal("103.500000")

def test_profit_and_roi():
    value = NavEngine.value("100", "1.035")
    assert NavEngine.profit("100", "1.035", "100") == Decimal("3.500000")
    assert NavEngine.roi_percent(value, "100") == Decimal("3.5")

def test_simple_daily_accrual():
    rate = YieldEngine.period_rate_from_apr("3.65")
    reward = YieldEngine.simple_accrual("1000", rate)
    assert reward == Decimal("0.100000")

def test_compound():
    result = YieldEngine.compound("100", [Decimal("0.01"), Decimal("0.02")])
    assert result == Decimal("103.020000")

def test_fee():
    assert FeeEngine.percentage("100", "1") == Decimal("1.000000")
    assert FeeEngine.net_after_fee("100", "1") == Decimal("99.000000")

def test_compounding_fee():
    result = CompoundingEngine.apply("100", "0.01", "0.50")
    assert result == Decimal("100.500000")

def test_invalid_principal():
    with pytest.raises(ValueError):
        NavEngine.roi_percent("100", "0")
