# VALORA NAV / Yield / Compounding v1.3

## NAV

NAV is separated from Points.

For an investment position:

NAV = Units × UnitPrice

Profit = NAV - Principal

ROI% = (NAV - Principal) / Principal × 100

## Yield

The engine supports:
- APR-period conversion
- APY-period conversion
- simple period accrual
- variable-rate compounding

Variable rates are represented as a sequence of period rates:

FutureValue = Principal × Π(1 + r_i)

This is preferable to assuming a permanently fixed annual rate.

## Fees

Fees are modeled separately and deducted explicitly.

NetValue = GrossValue - Fee

## Important production rule

Do not advertise a fixed yield unless the external investment product
actually guarantees it. The external provider's realized rate and NAV
must be treated as source data.

## Points

Points remain an internal accounting unit and do not become the NAV.

## External investment

The production connector must retrieve:
- actual asset
- principal
- units
- current NAV/unit price
- realized yield
- fees
- timestamps
- provider transaction reference

before updating VALORA's investment state.
