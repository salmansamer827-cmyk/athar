# VALORA v1.3

NAV, Yield, Fees and Compounding Engine.

Core mathematical separation:
Points != Investment Units != NAV.

Run:
cd backend
python -m pytest
