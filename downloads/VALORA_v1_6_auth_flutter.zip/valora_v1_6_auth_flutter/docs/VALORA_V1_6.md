# VALORA v1.6 — Authentication + Mobile Contract

## Backend
Added:
- Authentication service prototype
- Portfolio aggregation service
- Auth API
- Portfolio summary API

## Mobile
Added the first domain model for Portfolio Summary.

## Security
The current password hashing file is a prototype only.
Before production:
- use Argon2id or bcrypt
- use short-lived access tokens + refresh token rotation
- enforce MFA for sensitive operations
- rate-limit authentication
- verify email
- encrypt secrets at rest
- never store Binance API secrets in the mobile application

## Financial invariant
The mobile dashboard is a presentation layer.
The authoritative values come from the backend ledger and reconciled provider data.
