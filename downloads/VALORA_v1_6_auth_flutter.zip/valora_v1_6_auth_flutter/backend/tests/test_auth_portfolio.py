from decimal import Decimal
from app.services.auth_service import AuthService
from app.services.portfolio_service import PortfolioService

def test_password_hash_and_verify():
    s = AuthService()
    digest, salt = s.hash_password("StrongPassword123")
    assert s.verify_password("StrongPassword123", digest, salt)
    assert not s.verify_password("WrongPassword123", digest, salt)

def test_portfolio_summary():
    result = PortfolioService().summarize([
        {"principal": "100", "current_value": "100.80"},
        {"principal": "50", "current_value": "50.20"},
    ])
    assert result["total_value"] == Decimal("151.000000")
    assert result["principal"] == Decimal("150.000000")
    assert result["profit"] == Decimal("1.000000")
