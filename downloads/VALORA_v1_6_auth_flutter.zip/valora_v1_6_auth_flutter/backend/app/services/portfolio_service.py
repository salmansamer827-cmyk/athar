from decimal import Decimal
from ..core.decimal_math import money

class PortfolioService:
    def summarize(self, positions):
        total = Decimal("0")
        principal = Decimal("0")
        yield_value = Decimal("0")

        for p in positions:
            current = money(p["current_value"])
            original = money(p["principal"])
            total += current
            principal += original
            yield_value += current - original

        total = money(total)
        principal = money(principal)
        yield_value = money(yield_value)

        roi = Decimal("0")
        if principal > 0:
            roi = (total - principal) / principal * Decimal("100")

        return {
            "total_value": total,
            "principal": principal,
            "profit": yield_value,
            "roi_percent": roi,
        }
