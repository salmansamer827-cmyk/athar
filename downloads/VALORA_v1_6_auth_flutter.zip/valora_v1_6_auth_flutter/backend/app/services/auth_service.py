from dataclasses import dataclass
from hashlib import sha256
import secrets

@dataclass(frozen=True)
class UserCredentials:
    user_id: str
    email: str
    password_hash: str
    salt: str

class AuthService:
    """
    Prototype authentication service.
    Production must use Argon2id/bcrypt, secure token storage,
    email verification, MFA, rate limiting and account lockout.
    """

    def hash_password(self, password: str, salt: str | None = None):
        if len(password) < 8:
            raise ValueError("Password must be at least 8 characters")
        salt = salt or secrets.token_hex(16)
        digest = sha256((salt + password).encode()).hexdigest()
        return digest, salt

    def verify_password(self, password: str, password_hash: str, salt: str):
        digest, _ = self.hash_password(password, salt)
        return secrets.compare_digest(digest, password_hash)
