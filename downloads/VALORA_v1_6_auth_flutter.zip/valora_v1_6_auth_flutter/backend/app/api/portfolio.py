from fastapi import APIRouter
from ..services.portfolio_service import PortfolioService

router = APIRouter(prefix="/portfolio", tags=["portfolio"])
service = PortfolioService()

@router.post("/summary")
def summary():
    # Demo endpoint. Production loads positions from PostgreSQL.
    positions = [
        {
            "principal": "100",
            "current_value": "100.800000",
        }
    ]
    result = service.summarize(positions)
    return {k: str(v) for k, v in result.items()}
