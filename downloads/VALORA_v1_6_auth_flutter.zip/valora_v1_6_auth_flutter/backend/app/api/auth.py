from fastapi import APIRouter
from ..services.auth_service import AuthService

router = APIRouter(prefix="/auth", tags=["auth"])
service = AuthService()

@router.post("/password-check")
def password_check(password: str):
    password_hash, salt = service.hash_password(password)
    return {
        "valid": True,
        "password_hash": password_hash,
        "salt": salt,
    }
