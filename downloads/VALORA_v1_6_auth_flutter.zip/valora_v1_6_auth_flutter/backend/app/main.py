from fastapi import FastAPI
from .api.payments import router as payments_router
from .api.investments import router as investments_router
from .api.system import router as system_router
from .api.performance import router as performance_router
from .api.auth import router as auth_router
from .api.portfolio import router as portfolio_router

app = FastAPI(title="VALORA API", version="1.6.0")

app.include_router(payments_router)
app.include_router(investments_router)
app.include_router(system_router)
app.include_router(performance_router)
app.include_router(auth_router)
app.include_router(portfolio_router)

@app.get("/health")
def health():
    return {"status": "ok", "service": "VALORA", "version": "1.6.0"}
