class PortfolioSummary {
  final double totalValue;
  final double principal;
  final double profit;
  final double roiPercent;

  const PortfolioSummary({
    required this.totalValue,
    required this.principal,
    required this.profit,
    required this.roiPercent,
  });

  factory PortfolioSummary.fromJson(Map<String, dynamic> json) {
    return PortfolioSummary(
      totalValue: double.parse(json['total_value'].toString()),
      principal: double.parse(json['principal'].toString()),
      profit: double.parse(json['profit'].toString()),
      roiPercent: double.parse(json['roi_percent'].toString()),
    );
  }
}
