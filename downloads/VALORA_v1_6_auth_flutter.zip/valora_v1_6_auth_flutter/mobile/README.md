# VALORA Mobile v1.6

Flutter application structure:

lib/
  core/
    api/
    models/
    theme/
  features/
    auth/
    dashboard/
    wallet/
    points/
    investments/
    portfolio/
    transactions/

The mobile client must never contain Binance API secrets.
It communicates only with the VALORA backend over HTTPS.
