# VALORA v1.1

VALORA financial-core prototype.

### Core rule
100 USDT = 1,000,000 Points.

### Added in v1.1
- Payment Engine
- USDT / USDC support
- Investment Engine
- Investment Units
- Portfolio Allocation Engine
- FastAPI endpoints
- Financial-core tests

Run:
cd backend
python -m pytest
uvicorn app.main:app --reload
