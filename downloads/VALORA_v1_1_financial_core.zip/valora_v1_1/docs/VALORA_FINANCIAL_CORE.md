# VALORA Financial Core v1.1

## Fixed commercial rule
100 USDT = 1,000,000 VALORA Points
1 USDT = 10,000 Points

## Asset layer
Supported investment assets in this prototype:
- USDT
- USDC

## Separation of accounting layers
Points are internal accounting units.
Investment principal is an asset-denominated value.
Investment Units represent participation in an investment position.
NAV is calculated independently from Points.

## Allocation
Portfolio allocations must total exactly 100%.

Example:
USDT 60%
USDC 40%

## Production requirement
Deposits, withdrawals, custody, KYC/AML, external investment execution,
and reconciliation must be implemented and reviewed before handling real
customer funds.
