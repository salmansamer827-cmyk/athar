from decimal import Decimal

from app.services.payment_engine import PaymentEngine
from app.services.investment_engine import InvestmentEngine
from app.services.portfolio_engine import PortfolioEngine

def test_usdt_deposit():
    d = PaymentEngine().create_deposit("u1", "USDT", "100")
    assert d.amount == Decimal("100.000000")
    assert d.status == "PENDING"

def test_usdc_investment():
    p = InvestmentEngine().create("u1", "USDC", "100")
    assert p.principal == Decimal("100.000000")
    assert p.units == Decimal("100.000000")
    assert p.unit_price == Decimal("1.000000")

def test_portfolio_100_percent():
    result = PortfolioEngine().allocation(
        "100",
        {"USDT": "60", "USDC": "40"}
    )
    assert result["USDT"] == Decimal("60.000000")
    assert result["USDC"] == Decimal("40.000000")
