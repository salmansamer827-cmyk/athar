from dataclasses import dataclass
from decimal import Decimal
from enum import Enum

class Asset(str, Enum):
    USDT = "USDT"
    USDC = "USDC"

class InvestmentStatus(str, Enum):
    PENDING = "PENDING"
    ACTIVE = "ACTIVE"
    CLOSED = "CLOSED"

@dataclass(frozen=True)
class UserAccount:
    user_id: str
    points_balance: int = 0

@dataclass(frozen=True)
class InvestmentPosition:
    position_id: str
    user_id: str
    asset: Asset
    principal: Decimal
    units: Decimal
    unit_price: Decimal
    status: InvestmentStatus = InvestmentStatus.ACTIVE
