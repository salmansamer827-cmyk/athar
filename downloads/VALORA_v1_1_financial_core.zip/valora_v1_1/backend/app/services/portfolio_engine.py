from decimal import Decimal

from ..core.decimal_math import D, money

class PortfolioEngine:
    def allocation(self, total, allocations: dict[str, str]) -> dict[str, Decimal]:
        total = money(total)
        if total <= 0:
            raise ValueError("Total must be positive")

        parsed = {k.upper(): D(v) for k, v in allocations.items()}
        if any(v < 0 for v in parsed.values()):
            raise ValueError("Allocation percentages cannot be negative")

        total_pct = sum(parsed.values(), Decimal("0"))
        if total_pct != Decimal("100"):
            raise ValueError("Allocation percentages must total exactly 100")

        return {asset: money(total * pct / Decimal("100")) for asset, pct in parsed.items()}
