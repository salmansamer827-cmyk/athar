from dataclasses import dataclass
from decimal import Decimal
from uuid import uuid4

from ..core.decimal_math import D, money
from ..models.domain import Asset, InvestmentStatus

@dataclass(frozen=True)
class InvestmentPosition:
    position_id: str
    user_id: str
    asset: Asset
    principal: Decimal
    units: Decimal
    unit_price: Decimal
    status: InvestmentStatus

class InvestmentEngine:
    INITIAL_UNIT_PRICE = Decimal("1.000000")

    def create(self, user_id: str, asset: str, principal) -> InvestmentPosition:
        asset = Asset(asset.upper())
        principal = money(principal)

        if principal <= 0:
            raise ValueError("Investment principal must be positive")

        units = principal / self.INITIAL_UNIT_PRICE

        return InvestmentPosition(
            position_id=str(uuid4()),
            user_id=user_id,
            asset=asset,
            principal=principal,
            units=units,
            unit_price=self.INITIAL_UNIT_PRICE,
            status=InvestmentStatus.ACTIVE,
        )

    def current_value(self, position: InvestmentPosition, unit_price) -> Decimal:
        unit_price = money(unit_price)
        if unit_price < 0:
            raise ValueError("Unit price cannot be negative")
        return money(position.units * unit_price)
