from dataclasses import dataclass
from decimal import Decimal
from uuid import uuid4

from ..core.decimal_math import D, money

@dataclass(frozen=True)
class Deposit:
    deposit_id: str
    user_id: str
    asset: str
    amount: Decimal
    status: str

class PaymentEngine:
    SUPPORTED_ASSETS = {"USDT", "USDC"}

    def create_deposit(self, user_id: str, asset: str, amount) -> Deposit:
        asset = asset.upper()
        amount = money(amount)

        if asset not in self.SUPPORTED_ASSETS:
            raise ValueError("Unsupported payment asset")
        if amount <= 0:
            raise ValueError("Deposit amount must be positive")

        return Deposit(
            deposit_id=str(uuid4()),
            user_id=user_id,
            asset=asset,
            amount=amount,
            status="PENDING",
        )

    def confirm(self, deposit: Deposit) -> Deposit:
        if deposit.status != "PENDING":
            raise ValueError("Only pending deposits can be confirmed")

        return Deposit(
            deposit_id=deposit.deposit_id,
            user_id=deposit.user_id,
            asset=deposit.asset,
            amount=deposit.amount,
            status="CONFIRMED",
        )
