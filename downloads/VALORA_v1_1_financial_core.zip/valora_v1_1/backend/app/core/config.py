import os

class Settings:
    APP_NAME = "VALORA"
    POINTS_PER_USDT = "10000"
    DATABASE_URL = os.getenv(
        "DATABASE_URL",
        "postgresql+psycopg://valora:valora@localhost:5432/valora"
    )

settings = Settings()
