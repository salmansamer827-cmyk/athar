from fastapi import APIRouter
from ..services.payment_engine import PaymentEngine

router = APIRouter(prefix="/payments", tags=["payments"])
engine = PaymentEngine()

@router.post("/deposit")
def create_deposit(user_id: str, asset: str, amount: str):
    d = engine.create_deposit(user_id, asset, amount)
    return {
        "deposit_id": d.deposit_id,
        "user_id": d.user_id,
        "asset": d.asset,
        "amount": str(d.amount),
        "status": d.status,
    }
