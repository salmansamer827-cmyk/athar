from fastapi import APIRouter
from ..services.investment_engine import InvestmentEngine

router = APIRouter(prefix="/investments", tags=["investments"])
engine = InvestmentEngine()

@router.post("/")
def create_investment(user_id: str, asset: str, principal: str):
    p = engine.create(user_id, asset, principal)
    return {
        "position_id": p.position_id,
        "user_id": p.user_id,
        "asset": p.asset.value,
        "principal": str(p.principal),
        "units": str(p.units),
        "unit_price": str(p.unit_price),
        "status": p.status.value,
    }
