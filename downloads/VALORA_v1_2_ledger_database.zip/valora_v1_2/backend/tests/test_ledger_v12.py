from decimal import Decimal
import pytest

from app.services.ledger_service import Entry, LedgerService
from app.services.idempotency import IdempotencyStore
from app.services.wallet_service import WalletService

def test_balanced_usdt_transaction():
    ledger = LedgerService()
    ledger.validate([
        Entry("cash", "USDT", Decimal("100"), "DEBIT"),
        Entry("user_liability", "USDT", Decimal("100"), "CREDIT"),
    ])

def test_unbalanced_transaction_rejected():
    ledger = LedgerService()
    with pytest.raises(ValueError):
        ledger.validate([
            Entry("cash", "USDT", Decimal("100"), "DEBIT"),
            Entry("user_liability", "USDT", Decimal("99"), "CREDIT"),
        ])

def test_idempotency_returns_same_transaction():
    store = IdempotencyStore()
    first = store.reserve("PAY-001", "TX-1")
    second = store.reserve("PAY-001", "TX-2")
    assert first == second == "TX-1"

def test_wallet_cannot_overdraw():
    wallet = WalletService()
    with pytest.raises(ValueError):
        wallet.debit("50", "50.000001")
