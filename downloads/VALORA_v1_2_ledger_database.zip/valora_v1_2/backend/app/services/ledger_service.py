from dataclasses import dataclass
from decimal import Decimal
from uuid import uuid4

@dataclass(frozen=True)
class Entry:
    account: str
    asset: str
    amount: Decimal
    direction: str

class LedgerService:
    """
    In-memory validation layer for v1.2.
    PostgreSQL persistence is defined in db/schema.sql.
    """

    def validate(self, entries: list[Entry]) -> None:
        if not entries:
            raise ValueError("Ledger transaction must contain entries")

        totals: dict[str, Decimal] = {}
        for e in entries:
            if e.amount < 0:
                raise ValueError("Ledger amount cannot be negative")
            if e.direction not in {"DEBIT", "CREDIT"}:
                raise ValueError("Invalid direction")
            signed = e.amount if e.direction == "DEBIT" else -e.amount
            totals[e.asset] = totals.get(e.asset, Decimal("0")) + signed

        unbalanced = {a: v for a, v in totals.items() if v != 0}
        if unbalanced:
            raise ValueError(f"Unbalanced transaction: {unbalanced}")

    def transaction_id(self) -> str:
        return str(uuid4())
