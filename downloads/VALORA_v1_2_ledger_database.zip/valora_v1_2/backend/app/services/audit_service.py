from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

@dataclass
class AuditService:
    events: list[dict] = field(default_factory=list)

    def record(self, event_type: str, entity_id: str, payload: dict[str, Any]):
        event = {
            "event_type": event_type,
            "entity_id": entity_id,
            "payload": payload,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        self.events.append(event)
        return event
