from decimal import Decimal
from ..core.decimal_math import money

class WalletService:
    def credit(self, balance, amount):
        balance = money(balance)
        amount = money(amount)
        if amount <= 0:
            raise ValueError("Credit amount must be positive")
        return money(balance + amount)

    def debit(self, balance, amount):
        balance = money(balance)
        amount = money(amount)
        if amount <= 0:
            raise ValueError("Debit amount must be positive")
        if amount > balance:
            raise ValueError("Insufficient balance")
        return money(balance - amount)
