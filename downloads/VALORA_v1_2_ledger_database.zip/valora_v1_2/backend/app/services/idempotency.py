from dataclasses import dataclass

@dataclass
class IdempotencyStore:
    values: dict[str, str]

    def __init__(self):
        self.values = {}

    def reserve(self, key: str, transaction_id: str) -> str:
        if not key:
            raise ValueError("Idempotency key is required")

        existing = self.values.get(key)
        if existing is not None:
            return existing

        self.values[key] = transaction_id
        return transaction_id
