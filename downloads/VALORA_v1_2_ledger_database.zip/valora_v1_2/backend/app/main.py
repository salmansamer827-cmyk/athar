from fastapi import FastAPI
from .api.payments import router as payments_router
from .api.investments import router as investments_router
from .api.system import router as system_router

app = FastAPI(title="VALORA API", version="1.2.0")

app.include_router(payments_router)
app.include_router(investments_router)
app.include_router(system_router)

@app.get("/health")
def health():
    return {"status": "ok", "service": "VALORA", "version": "1.2.0"}
