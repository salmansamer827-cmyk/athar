from fastapi import APIRouter
from ..services.idempotency import IdempotencyStore

router = APIRouter(prefix="/system", tags=["system"])
store = IdempotencyStore()

@router.post("/idempotency")
def reserve_idempotency(key: str, transaction_id: str):
    result = store.reserve(key, transaction_id)
    return {"idempotency_key": key, "transaction_id": result}
