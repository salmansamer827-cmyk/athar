# VALORA Ledger v1.2

## Objective
Create an auditable accounting core where balances are derived from immutable
transactions rather than direct balance mutation.

## Rules

1. Every financial transaction must be balanced per asset.
2. A transaction uses DEBIT/CREDIT ledger entries.
3. Idempotency keys prevent duplicate processing.
4. Reversals are new transactions; old transactions are not deleted.
5. Audit events record important state changes.
6. Wallets cannot become negative.
7. PostgreSQL NUMERIC is used instead of binary floating point.

## Example

A confirmed 100 USDT deposit can be represented as:

DEBIT  Cash/Settlement       100 USDT
CREDIT User USDT Liability   100 USDT

The actual production mapping of custody, settlement and customer-liability
accounts must be finalized with the legal/custody model before live funds
are handled.
