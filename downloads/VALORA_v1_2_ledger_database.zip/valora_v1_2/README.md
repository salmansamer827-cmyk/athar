# VALORA v1.2

Database and accounting foundation.

Added:
- PostgreSQL schema
- Double-entry ledger validation
- Idempotency protection
- Audit service
- Wallet balance safety
- Tests

Run tests:
cd backend
python -m pytest
