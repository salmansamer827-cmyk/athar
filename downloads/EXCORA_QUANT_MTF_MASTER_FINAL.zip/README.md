# EXCORA QUANT MTF MASTER — FINAL

## Architecture

1D → 4H → 1H → 15M

- 1D: macro trend / EMA 50/200 / structure
- 4H: confirmation / structure
- 1H: liquidity sweep / displacement / MSS/CHoCH
- 15M: execution context / EMA / ATR / volume / VWAP / VP / FVG / OB / candle / momentum

## Telegram separation

Telegram is completely isolated in:

`telegram_notifier.py`

The quantitative engine is:

`excora_quant_mtf_master.py`

The engine does not build Telegram messages and does not contain Telegram API calls.

## Configuration

Copy `.env.example` to `.env` or export:

`EXCORA_TELEGRAM_TOKEN`

`EXCORA_TELEGRAM_CHAT_ID`

The current code reads environment variables directly, so you can also export them in Termux/Linux.

## Install

```bash
pip install -r requirements.txt
```

## Run

```bash
python excora_quant_mtf_master.py
```

## Important

This remains SIGNAL ONLY. There is no exchange order execution.

The score is normalized from a theoretical 110-point internal model to 0–100.

Default:
- Minimum score: 75
- Risk: 1%
- RR: 1:3
- Scan interval: 120 seconds
- Closed candles only
