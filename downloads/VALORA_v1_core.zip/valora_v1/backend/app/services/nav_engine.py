from decimal import Decimal
from ..core.decimal_math import D, money

class NavEngine:
    @staticmethod
    def unit_price(nav, units) -> Decimal:
        nav = D(nav)
        units = D(units)
        if nav < 0 or units <= 0:
            raise ValueError("NAV must be non-negative and units must be positive")
        return money(nav / units)

    @staticmethod
    def nav(units, unit_price) -> Decimal:
        units = D(units)
        unit_price = D(unit_price)
        if units < 0 or unit_price < 0:
            raise ValueError("Units and unit price cannot be negative")
        return money(units * unit_price)
