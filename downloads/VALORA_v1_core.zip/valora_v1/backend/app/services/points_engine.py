from dataclasses import dataclass
from ..core.decimal_math import points_from_usdt, usdt_from_points

@dataclass(frozen=True)
class PointPurchase:
    usdt_paid: str
    points_issued: int

class PointsEngine:
    def purchase(self, usdt) -> PointPurchase:
        points = points_from_usdt(usdt)
        return PointPurchase(str(usdt), points)

    def value(self, points: int) -> str:
        return str(usdt_from_points(points))
