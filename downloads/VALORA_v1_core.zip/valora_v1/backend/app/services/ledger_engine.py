from dataclasses import dataclass
from decimal import Decimal
from uuid import uuid4

@dataclass(frozen=True)
class LedgerEntry:
    transaction_id: str
    account: str
    asset: str
    amount: Decimal
    direction: str

class LedgerEngine:
    def create_transaction(self, entries):
        total_by_asset = {}
        for e in entries:
            if e.direction not in {"DEBIT", "CREDIT"}:
                raise ValueError("Invalid ledger direction")
            if e.amount < 0:
                raise ValueError("Ledger amount cannot be negative")
            sign = 1 if e.direction == "DEBIT" else -1
            total_by_asset[e.asset] = total_by_asset.get(e.asset, Decimal("0")) + sign * e.amount

        if any(v != 0 for v in total_by_asset.values()):
            raise ValueError("Ledger transaction is not balanced")

        txid = str(uuid4())
        return [LedgerEntry(txid, e.account, e.asset, e.amount, e.direction) for e in entries]
