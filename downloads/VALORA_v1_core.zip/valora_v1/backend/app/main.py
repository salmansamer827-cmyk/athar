from fastapi import FastAPI
from .services.points_engine import PointsEngine

app = FastAPI(title="VALORA API", version="1.0.0")
points_engine = PointsEngine()

@app.get("/health")
def health():
    return {"status": "ok", "service": "VALORA"}

@app.get("/points/quote")
def points_quote(usdt: str):
    purchase = points_engine.purchase(usdt)
    return {
        "usdt": purchase.usdt_paid,
        "points": purchase.points_issued,
        "rate": "10000 points per 1 USDT",
    }
