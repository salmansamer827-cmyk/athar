from decimal import Decimal, ROUND_DOWN, ROUND_HALF_UP

USDT_SCALE = Decimal("0.000001")
POINTS_PER_USDT = Decimal("10000")

def D(value) -> Decimal:
    return Decimal(str(value))

def money(value) -> Decimal:
    return D(value).quantize(USDT_SCALE, rounding=ROUND_HALF_UP)

def points_from_usdt(usdt) -> int:
    amount = D(usdt)
    if amount < 0:
        raise ValueError("USDT amount cannot be negative")
    result = amount * POINTS_PER_USDT
    if result != result.to_integral_value():
        raise ValueError("USDT amount produces fractional points")
    return int(result)

def usdt_from_points(points: int) -> Decimal:
    if points < 0:
        raise ValueError("Points cannot be negative")
    return money(D(points) / POINTS_PER_USDT)
