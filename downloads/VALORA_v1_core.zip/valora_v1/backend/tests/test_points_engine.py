from app.core.decimal_math import points_from_usdt, usdt_from_points

def test_100_usdt_equals_one_million_points():
    assert points_from_usdt("100") == 1_000_000

def test_50_usdt_equals_500k_points():
    assert points_from_usdt("50") == 500_000

def test_one_usdt_equals_10k_points():
    assert points_from_usdt("1") == 10_000

def test_reverse_conversion():
    assert usdt_from_points(1_000_000) == 100
    assert usdt_from_points(500_000) == 50
