# VALORA v1.0

Financial architecture prototype.

## Fixed initial rule
100 USDT = 1,000,000 VALORA Points
1 USDT = 10,000 Points

## Core separation
Points are an internal accounting unit.
Investment principal/NAV are separate records.
External investment assets are not stored as Points.

## Run
cd backend
python -m pytest
uvicorn app.main:app --reload
